export default function extract(stringArgs?: string): Promise<void>;
